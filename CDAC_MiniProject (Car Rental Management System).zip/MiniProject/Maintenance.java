package MiniProject;

class QueueEmptyException extends Exception
{
    String str;
    public QueueEmptyException(){}
    public QueueEmptyException(String s)
    {
        str = s;
    }
    public String toString()
    {
        return (str+": Maintenance Queue is Empty");
    }
}

class Maintenance<T>
{
    Node front, rear;
    static int count=0;
    
    class Node
    {
        T data;
        Node next;
        
        Node(T x)
        {
            data = x;
            next = null;
        }
    }
    
    public Maintenance()
    {
        front = rear = null;
    }
    
    public boolean isEmpty()
    {
        return (front == null);
    }
    
    
     <T> void remove()
    {
        Node temp;
        temp=front;
            
        try
        {
            if(front==null)
            {
            QueueEmptyException ex=new QueueEmptyException("Exception Occured!");
            throw ex;
            }
            
            else
            {
            front=front.next;
            temp.next=null;
            count--;
            System.out.println("\n"+temp.data+" removed From maintenance");
            }
        }
        
        catch(QueueEmptyException e)
        {
            System.out.println(e);
        }
    }
     
   void insert(T data)
    {
        Node temp = new Node(data);
        if(isEmpty())
        {
            front = rear = temp;
            count++;
        }
        else
        {
            rear.next = temp;
            rear = temp;
            count++;
        }
    }
    
    <T> void show()
    {
        Node n=front;
        int i=1;
        
        try
        {
            if(front==null)
            {
            QueueEmptyException e=new QueueEmptyException("Exception Occured!");
            throw e;
            }
            
        else
            {
                System.out.println("\nTotal cars in maintenance: "+count);

                while(n.next!=null)
                {
                    System.out.println("Car "+(i++)+": "+n.data);
                    n=n.next;
                }
                System.out.println("Car "+(i)+": "+n.data);
            }
        }
        
        catch(QueueEmptyException e)
        {
            System.out.println(e);
        }
    }
}