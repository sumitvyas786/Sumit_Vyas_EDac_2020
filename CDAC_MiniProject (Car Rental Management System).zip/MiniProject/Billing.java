package MiniProject;

class Billing extends Customer
{
    private static int bill_no=1000;
    Car car;
    
    
    Billing(Car car)
    {
        super(1);
        this.car=car;
        this.gen_bill();
    }
    
    void gen_bill()
    {
        int days=calculate_days(); 
        int car_price=car.selected_price;
        
        int amount=days*car_price;
        float gst=amount*0.18f;
        float total=gst+amount;
        
        Admin obj=new Admin();
        obj.set_sales(total);
        
        System.out.println("\n\t|***********************************************************************|");
        System.out.println("\t|\t\t     Car Rental Management System\t\t\t|\n\t|\t\tDesigned by Sumit Vyas & Rakesh Samanta\t\t\t|");
        System.out.println("\t|\t\t\tGSTIN: 25SREDA3201Q3G8\t\t\t\t|");
        System.out.println("\t|-----------------------------------------------------------------------|");
        System.out.println("\t|\t\t\t  TRANSACTION RECEIPT\t\t\t\t|");
        System.out.print("\t|\t\t\t     Bill No. "+(bill_no++)+"\t\t\t\t|");
        System.out.printf("\n\t|\tCar Name %51s\t|",car.selected_car);
        System.out.printf("\n\t|\tDuration\t\t\t\t%8d %s to %d %s  |",frm_day,month_name(frm_month),to_day,month_name(to_month));
        System.out.print("\n\t|\t\t\t\t\t\t      ---------------   |");
        System.out.printf("\n \t|\tCar Rent %42d\t\t|",car_price);
        System.out.printf("\n\t|\tRental Days %38d\t\t|",days);
        System.out.printf("\n\t|\tRental Price %39d\t\t|",amount);
        System.out.printf("\n\t|\tGST  %51.3f\t|",gst);
        System.out.print("\n\t|-----------------------------------------------------------------------|");
        System.out.printf("\n\t|\tTotal %50.3f\t|",total);
        System.out.println("\n\t*************************************************************************\n");
    }
    
    String month_name(int m)
    {
        String name="";
        switch(m)
        {
            case 1:
                name="Jan";
                break;
            case 2:
                name="Feb";
                break;
            case 3:
                name="Mar";
                break;
            case 4:
                name="Apr";
                break;
            case 5:
                name="May";
                break;
            case 6:
                name="Jun";
                break;
            case 7:
                name="Jul";
                break;
            case 8:
                name="Aug";
                break;
            case 9:
                name="Sep";
                break;
            case 10:
                name="Oct";
                break;
            case 11:
                name="Nov";
                break;
            case 12:
                name="Dec";
                break;
        }
        return name;
    }
}