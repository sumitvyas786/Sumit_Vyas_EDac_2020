package MiniProject;

interface Interface
{
    void select();
}