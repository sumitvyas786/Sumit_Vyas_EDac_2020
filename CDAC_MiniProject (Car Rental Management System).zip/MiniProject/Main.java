package MiniProject;
import java.util.*;

class Main
{
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        Car car=new Car();
        Maintenance <String> queue=new Maintenance <>();
        int user=1;
        
        while(user!=0)
        {
            System.out.println("\nSelect User type: \n1. Admin\n2. Customer\n3. About Company\n0. EXIT");
            user=scan.nextInt();
            switch(user)
            {
                    case 1:
                            Admin admin=new Admin(car,queue);
                            break;

                    case 2:
                            Customer cust=new Customer(car);
                            break;
                            
                    case 3:
                            FileIO f=new FileIO();
                            break;
                            
                    case 0:
                        break;

                    default:
                    System.out.println("Invalid Choice!");
            }
        }
        
        System.out.println("\nThankyou :)");
    }
}