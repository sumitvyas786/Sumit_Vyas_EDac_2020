package MiniProject;
import java.util.*;

class Customer implements Interface
{
    Car car;
    
    private static String name;
    private static long mob;
    private static String address;
    private static String id;
    private static String liscence;
    
    protected static int frm_day;
    protected static int frm_month;
    protected static int to_day;
    protected static int to_month;
    
    private static String feedback;
    
    Scanner scan=new Scanner(System.in);
    Customer(Car car)
    {
        this.car=car;
        this.details();
        this.select();
        this.duration();
        this.thread();
        this.bill();
        this.feedback();
    }
    
    void thread()
    {
        System.out.print("\n\t\t<< Please wait (4 seconds) while BILL is getting generated >>\n");
        try
        {
                Thread.sleep(2000);
        }
        
        catch(InterruptedException e)
        {
                System.out.println(e);
        }
    }
    
    Customer(int x)
    {}
    
    void details()
    {
        System.out.println("\nEnter Customer Details");
        System.out.print("Enter your Name: ");
        name=scan.nextLine();
        System.out.print("Enter your Mobile No. ");
        mob=scan.nextLong();
        System.out.print("Enter your Address: ");
        scan.nextLine();
        address=scan.nextLine();
        System.out.print("Enter your Aadhar ID/Voter ID No. ");
        id=scan.next();
        System.out.print("Enter your Driving Liscence No. ");
        liscence=scan.next();
    }
    
    String cust_name()
    {
        return name;
    }
    
    static void cust_feedback()
    {
        System.out.println(feedback);
    }
    
    public void select()
    {
        car.select();
    }
    
    void duration()
    {
        System.out.print("\nSet Booking Duration\n");
        System.out.print("From\nDay (dd): ");
        frm_day=scan.nextInt();
        System.out.print("Month (mm): ");
        frm_month=scan.nextInt();
        System.out.print("To\nDay (dd): ");
        to_day=scan.nextInt();
        System.out.print("Month (mm): ");
        to_month=scan.nextInt();
    }
    
    void bill()
    {
        Billing bill=new Billing(car);
    }
    
    void feedback()
    {
        System.out.println("\nThanks "+name+" for booking with us.\n\nAlso please share your valuable feedback. \nIt'll always be very helpful for us to serve you better.\n\nWrite here:");
        scan.nextLine();
        feedback=scan.nextLine();
    }
    
    void show_details()
    {
        System.out.println("\nCustomer Details: ");
        System.out.printf("Name: %27s",name);
        System.out.printf("\nMobile No. %25d",mob);
        System.out.printf("\nAddress: %30s",address);
        System.out.printf("\nAadhar ID/Voter ID No. %12s",id);
        System.out.printf("\nDriving Liscence No. %15s\n",liscence);
    }
    
    int calculate_days()
    {
        int months=to_month-frm_month;
        int day;
        
        if(months<1)
            day=to_day-frm_day;
        
        else if(months==1)
            day=30-frm_day+to_day;
        
        else
        {
            int sum=0;
            for(int i=0;i<months;i++)
                sum=sum+30;
            
            day=30-frm_day+to_day+sum;
        }
        
        return day;
    }
    
}