-- Voting Management System
-- By:
-- (200940581031) Sumit Vyas
-- (200940381058) Nutan Gharate

create database Mini_Project;
use Mini_Project;
drop database Mini_Project;


-- /////////////////////////////////////////////////////////////////////////////////////
-- 1. Political Party Table:
create table politicalparty(
party_id int primary key,
party_name varchar(80),
emblem varchar(20)
);
insert into politicalparty values(350,'Bahujan Samaj Party','Elephant');
insert into politicalparty values(351,'Bharatiya Janata Party','Lotus');
insert into politicalparty values(352,'Indian National Congress','Hand Palm');
insert into politicalparty values(353,'Nationalist Congress Party','Clock');
insert into politicalparty values(354,'National Peoples Party','Book');
-- /////////////////////////////////////////////////////////////////////////////////////



-- /////////////////////////////////////////////////////////////////////////////////////
-- 2. Election Table:
create table election(
election_id int primary key,
election_name varchar(20),
election_date date
);
insert into election values(320,'Rajya Sabha','2020-04-23');
insert into election values(321,'Vidhan Sabha','2020-06-03');
insert into election values(322,'Lok Sabha','2020-10-28');
insert into election values(323,'Nagar Palika','2020-08-14');
insert into election values(324,'Village Panchyat','2019-12-04');
-- /////////////////////////////////////////////////////////////////////////////////////



-- /////////////////////////////////////////////////////////////////////////////////////
-- 3. Voter Table:
create table voter(
voter_id int primary key ,
voter_Name varchar(30),
voter_constitution  varchar(10),
voter_DateOfBirth date,
voter_Phn_no varchar(10),
voter_Gender char(1),
Address varchar(100),
hasvoted boolean
);
insert into voter values(111222,'Rahul Nema','Bhopal','1992-12-03',8389893726,'M','Bhoapl',1);
insert into voter values(111223,'Nisha Verma','Sagar','1976-02-15',8381243233,'F','Sagar',0);
insert into voter values(111224,'Shubham Seth','Ujjain','1992-04-24',2342353432,'M','Shivni',0);
insert into voter values(111225,'Arun Kumar','Jabalpur','1992-11-04',2343253226,'M','Jabalpur',1);
insert into voter values(111226,'Smita Sharma','Vidisha','1992-09-13',8389892343,'F','Vidisha',0);
-- /////////////////////////////////////////////////////////////////////////////////////



-- /////////////////////////////////////////////////////////////////////////////////////
-- 4. City Table:
create table city(
city_id int primary key,
city_name varchar(20)
);
insert into city value(1,'Bhopal');
insert into city value(2,'Ujjain');
insert into city value(3,'Indore');
insert into city value(4,'Jabalpur');
insert into city value(5,'Sagar');
-- /////////////////////////////////////////////////////////////////////////////////////



-- /////////////////////////////////////////////////////////////////////////////////////
-- 5. District Table:
create table district(
district_id int primary key,
district_name varchar(20),
city_id int,
constraint district_cityid_fk foreign key (city_id) references city(city_id)
);
insert into district value(101,'Bhopal',1);
insert into district value(102,'Ujjain',2);
insert into district value(103,'Indore',3);
insert into district value(104,'Jabalpur',4);
insert into district value(105,'Sagar',5);
-- /////////////////////////////////////////////////////////////////////////////////////



-- /////////////////////////////////////////////////////////////////////////////////////
-- 6. Town Table:
create table town(
town_id int primary key,
town_name varchar(10),
district_id int(5),
constraint town_district_fk foreign key (district_id) references district(district_id)
);
insert into town values(10,'Vidisha',101);
insert into town values(11,'Alampur',102);
insert into town values(12,'Aranya',103);
insert into town values(13,'Bijapur',104);
insert into town values(14,'Deori',105);
-- /////////////////////////////////////////////////////////////////////////////////////





-- /////////////////////////////////////////////////////////////////////////////////////
-- 7. Village Table:
create table village(
village_id int primary key,
village_name varchar(30),
city_id int,
town_id int,
district_id int,
constraint village_cityid_fk foreign key (city_id) references city(city_id),
constraint village_districtid_fk foreign key (district_id) references district(district_id),
constraint village_townid_fk foreign key (town_id) references town(town_id)
);
insert into village value(111,'Bijapur',1,10,101);
insert into village value(112,'Bhanapur',2,11,102);
insert into village value(113,'Sultanpur',3,12,103);
insert into village value(114,'Sitara',4,13,104);
insert into village value(115,'Dumri',5,14,105);
-- /////////////////////////////////////////////////////////////////////////////////////




-- /////////////////////////////////////////////////////////////////////////////////////
-- 8. Candidate Table:
create table candidate(
candidate_id int primary key,
Candidate_name varchar(30),
candidate_age int,
candidate_constitution varchar(20),
party_id int,
election_id int,
city_id int,
town_id int,
constraint candidate_partyid_fk foreign key (party_id) references politicalparty(party_id),
constraint candidate_electionid_fk foreign key (election_id) references election(election_id),
constraint candidate_cityid_fk foreign key (city_id) references city(city_id),
constraint candidate_townid_fk foreign key (town_id) references town(town_id)
);
insert into candidate values(600,'Vipul Tembulvar',30,'Mumbai',350,320,1,10);
insert into candidate values(601,'Kiran Vaghmare',45,'Mumbai',351,321,2,11);
insert into candidate values(602,'Nisha Karolia',49,'Mumbai',352,322,3,12);
insert into candidate values(603,'Sohan Mishra',28,'Mumbai',353,323,4,13);
insert into candidate values(604,'Amol Shinde',25,'Mumbai',354,324,5,14);
-- /////////////////////////////////////////////////////////////////////////////////////



-- /////////////////////////////////////////////////////////////////////////////////////
-- 9. Ballet Box Table:
create table balletbox(
boxno int,
box_id int primary key,
election_id int,
city_id int,
town_id int,
village_id int,
voter_id int,
constraint balletbox_electionid_fk foreign key (election_id) references election(election_id),
constraint balletbox_cityid_fk foreign key (city_id) references city(city_id),
constraint balletbox_townid_fk foreign key (town_id) references town(town_id),
constraint balletbox_villageid_fk foreign key (village_id) references village(village_id),
constraint balletbox_voterid_fk foreign key (voter_id) references voter(voter_id)
);
insert into balletbox values(121,501,320,1,10,111,111222);
insert into balletbox values(122,502,321,2,11,112,111223);
insert into balletbox values(123,503,322,3,12,113,111224);
insert into balletbox values(124,504,323,4,13,114,111225);
insert into balletbox values(125,505,324,5,14,115,111226);
-- /////////////////////////////////////////////////////////////////////////////////////



-- /////////////////////////////////////////////////////////////////////////////////////
-- 10. Vote Count Table:
create table votecount(
count int primary key,
voter_id int,
box_id int,
candidate_id int,
party_id int,
constraint votecount_voterid_fk foreign key (voter_id) references voter(voter_id),
constraint votecount_boxid_fk foreign key (box_id) references balletbox(box_id),
constraint votecount_candidateid_fk foreign key (candidate_id) references candidate(candidate_id),
constraint votecount_partyid_fk foreign key (party_id) references politicalparty(party_id)
);
insert into votecount values(43423,111222,501,600,350);
insert into votecount values(32424,111223,502,601,351);
insert into votecount values(12335,111224,503,602,352);
insert into votecount values(45234,111225,504,603,353);
insert into votecount values(23423,111226,505,604,354);
-- /////////////////////////////////////////////////////////////////////////////////////



-- /////////////////////////////////////////////////////////////////////////////////////
-- 11. Vote_log Count Table:
create table voter_log(
voter_id int primary key,
voter_Name varchar(30),
voter_constitution  varchar(10),
voter_DateOfBirth date,
voter_Phn_no varchar(10),
voter_Gender char(1),
Address varchar(100),
hasvoted boolean
);
-- /////////////////////////////////////////////////////////////////////////////////////



-- /////////////////////////////////////////////////////////////////////////////////////
-- 1. Procedure for showing Candidate relation with Political Party using INNER JOIN:
delimiter $$
create procedure candidate_party()
begin
select candidate_id, candidate_name, candidate_age, Candidate_Constitution, election_id, candidate.party_id, party_name, emblem
from candidate inner join politicalparty on candidate.party_id = politicalparty.party_id;
end $$

call candidate_party();
-- /////////////////////////////////////////////////////////////////////////////////////



-- /////////////////////////////////////////////////////////////////////////////////////
-- 2. Procedure for showing Voter relation with Village/City/Town/District using triple INNER JOIN:
delimiter $$
create procedure voter_area()
begin
select v.voter_id, v.voter_name, v.voter_constitution, v.voter_dateofbirth, v.voter_phn_No, v.voter_gender,
vi.village_id, vi.village_name, vi.district_id,
b.box_id, b.boxno, b.election_id, b.city_id
from voter v
	inner join balletbox b on v.voter_id = b.voter_id
	inner join village vi on b.village_id = vi.village_id;
end $$

call voter_area();
-- /////////////////////////////////////////////////////////////////////////////////////



-- /////////////////////////////////////////////////////////////////////////////////////
-- 3. Procedure (out) + Function for calculating Total Votes of a candidate:
delimiter $$
create function votes() returns int
begin
	declare c int;
	set c = (select count(count) from votecount);
	return c;
end $$

delimiter $$
create procedure total_votes(out var int)
begin
declare var1 int;
set var1 = (select votes());
select var1 into var;
end $$

call total_votes(@var);
select @var as Total_Votes;
-- /////////////////////////////////////////////////////////////////////////////////////



-- /////////////////////////////////////////////////////////////////////////////////////
-- 4. Trigger for keeping the records of removed Voter into Voter_log Table:
Delimiter $$
Create trigger delete_voter after delete on voter
for each row
begin
insert into voter_log(voter_id, voter_name, voter_constitution, voter_DateOfBirth, voter_Phn_No, voter_Gender, Address, hasvoted)
values(old.voter_id, old.voter_name, old.voter_constitution, old.voter_DateOfBirth, old.voter_Phn_No, old.voter_Gender, old.Address, old.hasvoted);
end $$
-- /////////////////////////////////////////////////////////////////////////////////////



-- /////////////////////////////////////////////////////////////////////////////////////
-- 5. Trigger for  candidates:
Delimiter $$
Create trigger delete_voter after delete on voter
for each row
begin
end $$
-- /////////////////////////////////////////////////////////////////////////////////////






-- *testing statements:
insert into voter values(111228,'ZXCzxca','VizXCa','1992-09-13',8389893243,'F','Vid234ha',1);
delete from voter where voter_id=111228;

select * from voter;
select * from voter_log;
select * from election;
select * from balletbox;
select * from village;
select * from voter;
select * from city;
select * from town;
select * from candidate;
select * from politicalparty;
select * from votecount;
