package MiniProject;

import java.io.File;  
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileIO
{
    FileIO()
    {
        this.file();
    }
    
  void file()
  {
    try
    {
      File myObj = new File("C:\\Users\\$UMIT\\Documents\\NetBeansProjects\\JavaApplication1\\src\\MiniProject\\About_Company.txt");
      Scanner myReader = new Scanner(myObj);
      
      while (myReader.hasNextLine())
      {
        String data = myReader.nextLine();
        System.out.println(data);
      }
      myReader.close();
    }
    
    catch (FileNotFoundException e)
    {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
  }
}