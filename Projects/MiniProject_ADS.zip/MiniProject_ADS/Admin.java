package MiniProject;
import java.util.*;
import static java.lang.System.exit;

class Myexp4 extends Exception
{
    String exp;
    Myexp4(String exp)
    {
        super(exp);
        this.exp=exp;
    }
    public String getMessage()
    {
        return "User defined exception generated! "+exp;
    }
    public String toString()
    {
        return"\nException Occured!";
    }
}

class Admin
{
    static int stock=7;
    static float sales=0.0f;
    Car car;
    Maintenance <String> queue;
    
    Scanner scan=new Scanner(System.in);
    Customer cust1=new Customer(1);
    
    Admin(Car car, Maintenance queue)
    {
        this.car=car;
        this.queue=queue;
        this.password();
        this.methods();
    }
    
    Admin()
    {}
    
    private void password()
    {
        System.out.print("\nEnter UserName: ");
        String u=scan.next();
        System.out.print("Enter Password: ");
        String s=scan.next();
        
        
        try
        {
            if(("Admin".equals(u)) && ("Password".equals(s)))
                System.out.println("\nWelcome Admin");
            else
            {
                Myexp4 ex=new Myexp4("Wrong UserName/Password!");
                throw ex;
            }
                
        }
        catch(Myexp4 ex)
        {
            System.out.println(ex);
            System.out.println(ex.getMessage());
            exit(0);
        }
    }
    
    private int option=1;
    private void methods()
    {        
        while(option!=0)
        {
            System.out.println("\nSelect an option: \n1. Add Car\n2. Check Stock\n3. Maintenance\n4. Average Sales\n5. Customer Details\n6. Check Feedback\n0. EXIT");
            option=scan.nextInt();
            switch(option)
            {
                case 1:
                    car.add_car();
                    stock++;
                    System.out.println("\n1 Car added in stock for booking: ");
                    break;

                case 2:
                    System.out.println("\nAvailable Cars for booking: "+stock);
                    break;

                case 3:
                    int opt=1;
                    while(opt!=0)
                    {
                        System.out.println("\nSelect option: \n1. Total cars on maintenance\n2. Send car for maintenance\n3. Remove car from maintenance\n0. EXIT");
                        opt=scan.nextInt();    

                        if(opt==1)
                            queue.show();

                        else if(opt==2)
                        {
                            System.out.print("\nEnter car name for maintance: ");
                            scan.nextLine();
                            String car_name=scan.nextLine();
                            queue.insert(car_name);
                            stock--;
                        }

                        else if(opt==3)
                        {
                            queue.remove();
                            stock++;
                        }
                        
                        else if(opt==0)
                            break;

                        else
                                System.out.println("Invalid selection!");
                    }
                    break;

                case 4:
                    System.out.println("\nSales till now: Rs."+sales);
                    break;

                case 5:
                    cust1.show_details();
                    break;
                    
                case 6:
                    System.out.println("\nFeedback from "+cust1.cust_name()+": ");
                    Customer.cust_feedback();
                    break;
                    
                case 0:
                    break;

                default:
                    System.out.println("Invalid Choice!");
            }
        }
    }
    
    void set_sales(float total)
    {
        sales=sales+total;
        stock--;
    }
}