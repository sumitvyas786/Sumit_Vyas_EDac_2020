/**
1. Write a Java program to print 'Hello' on screen and then print your name on a separate line.
Expected Output :
Hello
Alexandra Abramov
*/


/**
class HW
{
	public static void main(String args[])
	{
		System.out.println("Hello");
		System.out.println("Alexandra Abramov");
	}
}
*/
















/**
2. Write a Java program to print the sum of two numbers.
Test Data: 74 + 36
*/


/**
class HW
{
	public static void main(String arg[])
	{
		//int a=74,b=36;
		System.out.println("Test Data: 74 + 36 = "+(74+36));
	}
}
*/














/**
3. Write a Java program to divide two numbers and print on the screen.
Test Data : 50/3
Expected Output : 16
*/


/**
class HW
{
	public static void main(String arg[])
	{
		//int a=50,b=3;
		System.out.println("Test Data : 50/3 = "+(50/3));
	}
}
*/
















/**
4. Write a Java program to print the result of the following operations.
Test Data:
a. -5 + 8 * 6
b. (55+9) % 9
c. 20 + -3*5 / 8
d. 5 + 15 / 3 * 2 - 8 % 3
Expected Output :
43
1
19
13
*/


/**
class HW
{
	public static void main(String arg[])
	{
		System.out.println("a. -5 + 8 * 6 = "+(-5+8*6));
		System.out.println("a.  (55+9) % 9 = "+((55+9) % 9));
		System.out.println("a. 20 + -3*5 / 8 = "+(20 + -3*5 / 8));
		System.out.println("a. 5 + 15 / 3 * 2 - 8 % 3 = "+(5 + 15 / 3 * 2 - 8 % 3));
	}
}
*/

















/**
5. Write a Java program that takes two numbers as input and display the product of two numbers.
Test Data:
Input first number: 25
Input second number: 5
Expected Output :
25 x 5 = 125
*/

/**
import java.util.Scanner;
class HW
{
	public static void main(String args[])
	{
		int x, y;
		Scanner sc= new Scanner(System.in);
		System.out.println("Input first number: ");
		x= sc.nextInt();
		System.out.println("Input second number: ");
		y= sc.nextInt();
		sc.close();
		System.out.println(x+" * "+y+" = " +x*y);	
	}
}
*/















/**
6. Write a Java program to print the sum (addition), multiply, subtract, divide and remainder of two numbers.
Test Data:
Input first number: 125
Input second number: 24
Expected Output :
125 + 24 = 149
125 - 24 = 101
125 x 24 = 3000
125 / 24 = 5
125 mod 24 = 5
*/

/**
import java.util.Scanner;
class HW
{
	public static void main(String args[])
	{
		int x,y;
		Scanner sc= new Scanner(System.in);
		System.out.println("Input first number: ");
		x=sc.nextInt();
		System.out.println("Input second number: ");
		y= sc.nextInt();
		sc.close();
		System.out.println(x+" + "+y+" = " +(x+y));
		System.out.println(x+" - "+y+" = " +(x-y));
		System.out.println(x+" * "+y+" = " +x*y);
		System.out.println(x+" / "+y+" = " +x/y);
		System.out.println(x+" % "+y+" = " +x%y);
	}
}
*/














/**
7. Write a Java program that takes a number as input and prints its multiplication
table upto 10.
Test Data:
Input a number: 8
Expected Output :
8 x 1 = 8
8 x 2 = 16
8 x 3 = 24
...
8 x 10 = 80
*/

/**
import java.util.Scanner;
class HW
{
	public static void main(String args[])
	{
		int x, i;
		Scanner sc= new Scanner(System.in);
		System.out.println("Input a number: ");
		x=sc.nextInt();
		sc.close();
		for(i=1;i<=10;i++)
		System.out.println(i+" * "+x+" = " +i*x);
	}
}
*/












/**
8. Write a Java program to display the following pattern.
Sample Pattern :
*/

/**
class HW
{
	public static void main(String args[])
	{
		System.out.println("   J    a    V     V    a");
		System.out.println("   J   a a    V   V    a a");
		System.out.println("J  J  aaaaa    V V    aaaaa");
		System.out.println(" JJ  a     a    V    a     a");
	}
}
*/














/**
9. Write a Java program to compute the specified expressions and print the output.
Test Data:
((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5))
Expected Output
2.138888888888889
*/


/**
class HW
{
	public static void main(String args[])
	{
		float x=25.5f, y=3.5f, z=40.5f, a=4.5f;
		double s=0.0d;
		s=(double)(x*y-y*y)/(z-a);
		System.out.println(s);
	}
}
*/
















/**
10. Write a Java program to compute a specified formula.
Specified Formula :
4.0 * (1 - (1.0/3) + (1.0/5) - (1.0/7) + (1.0/9) - (1.0/11))
Expected Output
2.9760461760461765
*/

/**
class HW
{
	public static void main(String args[])
	{
		int u=1, v=3, w=5, x=7, y=9, z=11;
		float a=1.0f, b=4.0f;
		double s=0.0d;
		s=(double)((double)b*((double)u-((double)a/v)+((double)a/w)-((double)a/x)+((double)a/y)-((double)a/z)));
		System.out.println(s);
	}
}
*/



















/**
11. Write a Java program to print the area and perimeter of a circle.
Test Data:
Radius = 7.5
Expected Output
Perimeter is = 47.12388980384689
Area is = 176.71458676442586
*/


/*
class HW
{
	public static void main(String args[])
	{
		double p=2.0d*((double)22/7)*7.5d;
		double s=((double)22/7)*7.5d*7.5d;
		System.out.println("Perimeter= "+p);
		System.out.println("Area= "+s);
	}
}
**/




















/**
12. Write a Java program that takes three numbers as input to calculate and print the average of the numbers.
*/


/**
import java.util.Scanner;
class HW
{
	public static void main(String args[ ])
	{
		int x,y,z;
		float av;
		Scanner s= new Scanner(System.in);
		System.out.println("Enter 1st No. ");
		x=  s.nextInt();
		System.out.println("Enter 2nd No. ");
		y= s.nextInt();
		System.out.println("Enter 3rd No. ");
		z= s.nextInt();
		av=(float)(x+y+z)/3;
		System.out.println("Average= "+av);
	}
}
**/






















/**
13. Write a Java program to print the area and perimeter of a rectangle.
Test Data:
Width = 5.5 Height = 8.5
Expected Output
Area is 5.6 * 8.5 = 47.60
Perimeter is 2 * (5.6 + 8.5) = 28.20
*/

/**
class HW
{
	public static void main(String args[])
	{
		float a=5.6f*8.5f;
		float p=(float)2*(5.6f+ 8.5f);
		System.out.println("Area is 5.6 * 8.5 = "+a);
		System.out.println("Perimeter is 2 * (5.6 + 8.5) = "+p);
	}
}
*/



















/**
15. Write a Java program to swap two variables.
*/


/**
class HW
{
	public static void main(String args[])
	{
		int x,y=5,z=6;
		System.out.println("Values before Swapping: y = "+y+", z = "+z);
		x=y;
		y=z;
		z=x;
		System.out.println("Values after Swapping: y = "+y+", z = "+z);
	}
}
*/
















/**
16. Write a Java program to print a face.
Expected Output
*/

/**
class HW
{
	public static void main(String args[])
	{
		System.out.println("  +\" \" \" \" \"+");
		System.out.println("[ |  o   o  | ]");
		System.out.println("  |    ^    |");
		System.out.println("  |  ' - '  |");
		System.out.println("  +---------+");
	}
}
*/













