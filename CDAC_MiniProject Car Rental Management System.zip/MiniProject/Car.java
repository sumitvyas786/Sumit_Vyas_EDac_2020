package MiniProject;
import java.util.*;

class Car implements Interface
{
    static String selected_car;
    static int selected_price;
    static int i=5, j=5;
    int count=0;
    
    int price[]=new int[10];
    Scanner scan = new Scanner(System.in);
    String cars[]=new String[10];
    
    
    public void select()
    {
        cars[0]="Hyundai Verna";
        cars[1]="Hyundai I20";
        cars[2]="Mahindra Scorpio";
        cars[3]="Tata Sumo";
        cars[4]="Tata Safari";
        cars[5]="Maruti Aulto";
        cars[6]="Swift Desire";

        price[0]=800;
        price[1]=900;
        price[2]=850;
        price[3]=750;
        price[4]=1050;
        price[5]=500;
        price[6]=780;
        
        System.out.println("\nSelect a Car: ");
        for(int i=0;i<cars.length;i++)
        {
            if(i<7)
                System.out.println("Car "+(i+1)+": "+cars[i]+"\t\tPrice: Rs."+price[i]);
            else
                System.out.println("Car "+(i+1)+": "+cars[i]+"\t\t\tPrice: Rs."+price[i]);
        }
        
        System.out.print("\nEnter Selected Car No. ");
        int s=scan.nextInt();
        selected_car=cars[s];
        selected_price=price[s];
    }
    
    void add_car()
    {
        System.out.print("\nEnter Car Name: ");
        if(count>0)
        {
            scan.nextLine();
        }
        cars[i++]=scan.nextLine();
        count++;
        
        System.out.print("Enter Car Rental Price: ");
        price[j++]=scan.nextInt();
    }
}