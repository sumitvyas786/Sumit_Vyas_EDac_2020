package Assignments;
//Half Pyramid:
/**
class Pattern
{
	public static void main(String args[ ])
	{
		for(int i=0;i<6;i++)
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print("* ");
			}
		System.out.println();
		}
	}
}
*/











//Inverted Half Pyramid:
/**
class Pattern
{
	public static void main(String args[ ])
	{
		for(int i=6;i>0;i--)
		{
			for(int j=0;j<i;j++)
			{
				System.out.print("* ");
			}
		System.out.println();
		}
	}
}
*/
















//Hollow Inverted Half Pyramid:
/**
class Pattern
{
	public static void main(String args[ ])
	{
		for(int i=6;i>0;i--)
		{
			for(int j=0;j<i;j++)
			{
				if(i>2 && i<6)
				{
					if(j==0 || j==(i-1))
					System.out.print("* ");
					else
					System.out.print("  ");
				}
				else
				System.out.print("* ");
			}
			System.out.println();
		}
	}
}
*/














//Full Pyramid:
/**
class Pattern
{
	public static void main(String args[ ])
	{
		for(int i=0;i<6;i++)
		{
			for(int j=6;j>i;j--)
				System.out.print("  ");
                        for(int k=i;k>=0;k--)
                                System.out.print(" *  ");
			System.out.println();
		}
	}
}
*/















//Inverted Full Pyramid:
/*
class Pattern
{
	public static void main(String args[ ])
	{
		for(int i=0;i<6;i++)
		{
			for(int j=i;j>=0;j--)
				System.out.print("  ");
                        for(int k=6;k>i;k--)
                                System.out.print(" *  ");
			System.out.println();
		}
	}
}
**/




















//Hollow Full Pyramid:
/**
class Pattern
{
	public static void main(String args[ ])
	{
		for(int i=0;i<6;i++)
		{
			for(int j=6;j>i;j--)
				System.out.print("  ");
                        for(int k=i;k>=0;k--)
                        {
                            if(i>0 && i<5)
                            {
                                if(k==i || k==0)
                                System.out.print(" *  ");    
                                else
                                System.out.print("    ");
                            }
                            else
                                System.out.print(" *  ");
                        }
			System.out.println();
		}
	}
}
*/









-----------------------------------------------------------










//Pyramid Pattern-3:
/**
class Pattern
{
	public static void main(String args[ ])
	{
		for(int i=0;i<9;i++)
		{
			for(int j=9;j>i;j--)
				System.out.print(" ");
                        for(int k=i;k>=0;k--)
                                System.out.print("* ");
			System.out.println();
		}
	}
}
*/























//Pyramid Pattern-2:
/**
class Pattern
{
	public static void main(String args[ ])
	{
		for(int i=0;i<9;i++)
		{
			for(int j=9;j>i;j--)
				System.out.print(" ");
                        for(int k=0;k<=i;k++)
                                System.out.print((k+1)+" ");
			System.out.println();
		}
	}
}
*/




















//Pyramid Pattern-1:
/**
class Pattern
{
	public static void main(String args[ ])
	{
		for(int i=1;i<=9;i++)
		{
			for(int j=9;j>i;j--)
				System.out.print(" ");
                        for(int k=0;k<i;k++)
                                System.out.print(i+" ");
			System.out.println();
		}
	}
}
*/




















//Pyramid Pattern-7:
/**
class Pattern
{
	public static void main(String args[ ])
	{
		for(int i=9;i>0;i--)
		{
			for(int j=i;j<=9;j++)
				System.out.print(" ");
                        for(int k=i;k>0;k--)
                                System.out.print(i+" ");
			System.out.println();
		}
	}
}
*/




















//Pyramid Pattern-4:
/**
class Pattern
{
	public static void main(String args[ ])
	{
		for(int i=0;i<9;i++)
		{
			for(int j=9;j>i;j--)
				System.out.print("  ");
                        for(int k=0;k<=i;k++)
                            System.out.print((k+1)+" ");
                        if(i>0)
                        {
                            for(int l=i;l>0;l--)
                                System.out.print(l+" ");
                        }
			System.out.println();
		}
	}
}
*/




















//Pyramid Pattern-5:-----------------------------------------
/**
class Pattern
{
	public static void main(String args[ ])
	{
		for(int i=9;i>0;i--)
		{
			for(int j=i;j>0;j--)
				System.out.print("  ");
                        for(int k=i;k<=9;k++)
                            System.out.print(k+" ");
                        if(i<9)
                        {
                            for(int l=8;l>=i;l--)
                                System.out.print(l+" ");
                        }
			System.out.println();
		}
	}
}
*/


















//Pyramid Pattern-6:
/**
class Pattern
{
	public static void main(String args[ ])
	{
		for(int i=0;i<9;i++)
		{
			for(int j=i;j>=0;j--)
				System.out.print(" ");
                        for(int k=9;k>i;k--)
                                System.out.print("* ");
			System.out.println();
		}
	}
}
*/